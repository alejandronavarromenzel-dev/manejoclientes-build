
package models

type Client struct {
	ID       int64
	Name     string
	Owner    string
	Email    string
	Phone    string
	Status   string
	Tags     string
	Industry string
	Notes    string
}

type Task struct {
	ID         int64
	ClientID   int64
	Title      string
	Description string
	Priority   string
	Status     string
	DueDate    *string
	StartDate  *string
	Progress   int
	Assignee   string
	ClientName string // join convenience
	CreatedAt  string
}
