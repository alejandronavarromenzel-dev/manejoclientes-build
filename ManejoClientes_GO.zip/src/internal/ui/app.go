
package ui

import (
	"database/sql"
	"fmt"
	"image/color"
	"strconv"
	"strings"

	fyne "fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"

	"manejoclientes/internal/db"
	"manejoclientes/internal/models"
)

var (
	w fyne.Window
)

func RunApp() {
	a := app.NewWithID("manejoclientes")
	a.Settings().SetTheme(theme.LightTheme())
	w = a.NewWindow("Manejo Clientes")
	w.Resize(fyne.NewSize(1366, 768))

	if err := db.Init(); err != nil {
		dialog.ShowError(err, w)
		return
	}

	nb := container.NewAppTabs()
	nb.Append(container.NewTabItem("Kanban", buildKanban()))
	nb.Append(container.NewTabItem("Clientes", buildClientes()))
	nb.Append(container.NewTabItem("Tareas", buildTareas()))
	nb.Append(container.NewTabItem("Reportes", buildReportes()))
	nb.Append(container.NewTabItem("Importar/Exportar", buildImportExport()))
	nb.Append(container.NewTabItem("Ajustes", buildAjustes()))
	nb.SetTabLocation(container.TabLocationTop)

	w.SetContent(nb)

	w.SetCloseIntercept(func(){
		// backup al cerrar
		if _, err := db.BackupNow(); err != nil {
			// no bloquear cierre por error de backup
		}
		w.Close()
	})
	w.ShowAndRun()
}

// ---------- Kanban ----------
func buildKanban() fyne.CanvasObject {
	col := func(title string, list *widget.List) fyne.CanvasObject {
		lbl := widget.NewLabelWithStyle(title, fyne.TextAlignCenter, fyne.TextStyle{Bold:true})
		return container.NewBorder(lbl, nil, nil, nil, list)
	}

	// Cargar datos
	var tasks []models.Task
	reload := func(){ tasks = queryTasks("", "", "") }
	reload()

	// separar por estado
	filter := func(status string) []models.Task {
		arr := []models.Task{}
		for _, t := range tasks { if t.Status == status { arr = append(arr, t) } }
		return arr
	}

	makeList := func(getter func()[]models.Task) *widget.List {
		items := getter()
		l := widget.NewList(
			func() int { return len(items) },
			func() fyne.CanvasObject { return widget.NewLabel("item") },
			func(i widget.ListItemID, o fyne.CanvasObject) {
				if i<0 || i>=len(items) { return }
				o.(*widget.Label).SetText(fmt.Sprintf("#%d %s — %s — %s", items[i].ID, items[i].Title, items[i].ClientName, items[i].Assignee))
			},
		)
		l.OnSelected = func(id widget.ListItemID) {
			if id<0 || id>=len(items) { return }
			showTaskEdit(items[id].ID, func(){ reload(); porHacer.Refresh(); enCurso.Refresh(); hecho.Refresh() })
		}
		l.OnUnselected = func(id widget.ListItemID){}
		return l
	}

	porHacer := makeList(func(){ return filter("Por hacer") })
	enCurso := makeList(func(){ return filter("En curso") })
	hecho := makeList(func(){ return filter("Hecho") })

	// controles
	btnAdd := widget.NewButton("Agregar tarea", func(){ showTaskEdit(0, func(){ reload(); porHacer.Refresh(); enCurso.Refresh(); hecho.Refresh() }) })
	controls := container.NewHBox(btnAdd)

	grid := container.NewGridWithColumns(3,
		col("Por hacer", porHacer),
		col("En curso", enCurso),
		col("Hecho", hecho),
	)

	return container.NewBorder(controls, nil, nil, nil, grid)
}

// ---------- Clientes ----------
func buildClientes() fyne.CanvasObject {
	search := widget.NewEntry(); search.SetPlaceHolder("Buscar cliente...")
	btn := widget.NewButton("Filtrar", nil)
	add := widget.NewButton("Agregar cliente", nil)

	table := widget.NewTable(
		func() (int, int) { return 0, 5 },
		func() fyne.CanvasObject { return widget.NewLabel("") },
		func(id widget.TableCellID, o fyne.CanvasObject) {},
	)
	refresh := func(){
		rows := queryClientsWithStats(strings.TrimSpace(search.Text))
		table.Length = func() (int, int) { return len(rows)+1, 5 }
		table.UpdateCell = func(id widget.TableCellID, o fyne.CanvasObject) {
			lbl := o.(*widget.Label)
			if id.Row == 0 {
				head := []string{"ID","Cliente","Responsable","Abiertas","Vencidas"}
				lbl.SetText(head[id.Col])
				return
			}
			r := rows[id.Row-1]
			switch id.Col {
			case 0: lbl.SetText(fmt.Sprintf("%d", r.id))
			case 1: lbl.SetText(r.name)
			case 2: lbl.SetText(r.owner)
			case 3: lbl.SetText(fmt.Sprintf("%d", r.open))
			case 4: lbl.SetText(fmt.Sprintf("%d", r.overdue))
			}
		}
		table.Refresh()
	}
	btn.OnTapped = refresh
	add.OnTapped = func(){ showClientEdit(0, refresh) }
	refresh()

	return container.NewBorder(
		container.NewHBox(add, widget.NewLabel("  "), search, btn),
		nil, nil, nil, table,
	)
}

// ---------- Tareas ----------
func buildTareas() fyne.CanvasObject {
	state := widget.NewSelect([]string{"","Por hacer","En curso","Hecho"}, func(string){})
	resp := widget.NewEntry(); resp.SetPlaceHolder("Responsable")
	cl := widget.NewEntry(); cl.SetPlaceHolder("Cliente")
	btn := widget.NewButton("Filtrar", nil)
	add := widget.NewButton("Agregar tarea", nil)
	mark := widget.NewButton("Marcar Hecho", nil)

	cols := []string{"ID","Cliente","Título","Estado","Vence","Resp.","Prioridad","%"}
	data := [][]string{}
	table := widget.NewTable(
		func() (int, int) { return len(data)+1, len(cols) },
		func() fyne.CanvasObject { return widget.NewLabel("") },
		func(id widget.TableCellID, o fyne.CanvasObject) {
			lbl := o.(*widget.Label)
			if id.Row==0 { lbl.SetText(cols[id.Col]); return }
			lbl.SetText(data[id.Row-1][id.Col])
		},
	)
	selectedID := int64(0)
	table.OnSelected = func(id widget.TableCellID){
		if id.Row>0 { if v, err := strconv.ParseInt(data[id.Row-1][0], 10, 64); err==nil { selectedID = v } }
	}
	refresh := func(){
		rows := queryTasks(state.Selected, resp.Text, cl.Text)
		data = make([][]string, 0, len(rows))
		for _, r := range rows {
			data = append(data, []string{
				fmt.Sprintf("%d", r.ID), r.ClientName, r.Title, r.Status,
				valueOr(r.DueDate, ""), r.Assignee, r.Priority, fmt.Sprintf("%d", r.Progress),
			})
		}
		table.Refresh()
	}
	btn.OnTapped = refresh
	add.OnTapped = func(){ showTaskEdit(0, refresh) }
	mark.OnTapped = func(){ if selectedID>0 { exec("UPDATE tasks SET status='Hecho', progress=100 WHERE id=?", selectedID); refresh() } }
	refresh()

	toolbar := container.NewHBox(add, mark, widget.NewLabel("  Estado:"), state, widget.NewLabel("  Resp:"), resp, widget.NewLabel("  Cliente:"), cl, btn)
	return container.NewBorder(toolbar, nil, nil, nil, table)
}

// ---------- Reportes ----------
func buildReportes() fyne.CanvasObject {
	reportSel := widget.NewSelect(
		[]string{"Tareas por estado","Vencidas por responsable","Tareas por cliente","Productividad semanal"}, func(string){} )
	reportSel.SetSelectedIndex(0)
	btnCsv := widget.NewButton("Exportar Excel", nil)

	cols := []string{"Col1","Col2"}
	data := [][]string{}
	table := widget.NewTable(
		func() (int, int) { return len(data)+1, len(cols) },
		func() fyne.CanvasObject { return widget.NewLabel("") },
		func(id widget.TableCellID, o fyne.CanvasObject) {
			lbl := o.(*widget.Label)
			if id.Row==0 { lbl.SetText(cols[id.Col]); return }
			lbl.SetText(data[id.Row-1][id.Col])
		},
	)
	load := func(){
		name := reportSel.Selected
		rows, headers := queryReport(name)
		cols = headers
		data = rows
		table.Length = func() (int, int) { return len(data)+1, len(cols) }
		table.Refresh()
	}
	btnCsv.OnTapped = func(){
		if err := exportReportToExcel(reportSel.Selected); err != nil { dialog.ShowError(err, w) } else { dialog.ShowInformation("Exportar", "Excel exportado", w) }
	}
	reportSel.OnChanged = func(string){ load() }
	load()

	header := container.NewHBox(widget.NewLabelWithStyle("Reporte:", fyne.TextAlignLeading, fyne.TextStyle{Bold:true}), reportSel, btnCsv)
	return container.NewBorder(header, nil, nil, nil, table)
}

// ---------- Import/Export ----------
func buildImportExport() fyne.CanvasObject {
	info := widget.NewRichTextFromMarkdown("**Importar/Exportar**
- Clientes (XLSX)
- Tareas (XLSX)")
	impC := widget.NewButton("Importar clientes (XLSX)", func(){ doImportClientsXLSX() })
	expC := widget.NewButton("Exportar clientes (XLSX)", func(){ doExportClientsXLSX() })
	impT := widget.NewButton("Importar tareas (XLSX)", func(){ doImportTasksXLSX() })
	expT := widget.NewButton("Exportar tareas (XLSX)", func(){ doExportTasksXLSX() })
	return container.NewVBox(info, impC, expC, impT, expT)
}

// ---------- Ajustes ----------
func buildAjustes() fyne.CanvasObject {
	lbl := widget.NewLabel("Backups automáticos al cerrar: ACTIVOS
Carpeta: backups\")
	lbl.TextStyle = fyne.TextStyle{Monospace:true}
	return container.NewVBox(widget.NewLabelWithStyle("Ajustes", fyne.TextAlignLeading, fyne.TextStyle{Bold:true}), lbl)
}

// ---------- Utilidades de datos ----------
func valueOr(s *string, def string) string { if s==nil {return def}; return *s }

func exec(sql string, args ...any) error { _, err := db.DB.Exec(sql, args...); return err }

func queryTasks(state, resp, cl string) []models.Task {
	q := `SELECT t.id, t.client_id, c.name as client_name, t.title, t.description, t.priority, t.status, t.due_date, t.start_date, t.progress, t.assignee, t.created_at
		FROM tasks t JOIN clients c ON t.client_id=c.id
		WHERE (?='' OR t.status=?) AND (?='' OR t.assignee LIKE ?) AND (?='' OR c.name LIKE ?)
		ORDER BY t.due_date IS NULL, t.due_date ASC`
	like := func(s string) string { return "%"+s+"%" }
	rows, err := db.DB.Query(q, state, state, resp, like(resp), cl, like(cl))
	if err != nil { return nil }
	defer rows.Close()
	out := []models.Task{}
	for rows.Next(){
		var r models.Task
		var due, start sql.NullString
		rows.Scan(&r.ID, &r.ClientID, &r.ClientName, &r.Title, &r.Description, &r.Priority, &r.Status, &due, &start, &r.Progress, &r.Assignee, &r.CreatedAt)
		if due.Valid { s := due.String; r.DueDate = &s }
		if start.Valid { s := start.String; r.StartDate = &s }
		out = append(out, r)
	}
	return out
}

func queryClientsWithStats(search string) []struct{id int64; name, owner string; open, overdue int} {
	q := `SELECT c.id, c.name, c.owner,
		SUM(CASE WHEN t.status!='Hecho' THEN 1 ELSE 0 END) as open_tasks,
		SUM(CASE WHEN t.status!='Hecho' AND t.due_date IS NOT NULL AND date(t.due_date) < date('now') THEN 1 ELSE 0 END) as overdue
		FROM clients c LEFT JOIN tasks t ON t.client_id=c.id
		WHERE c.name LIKE ?
		GROUP BY c.id, c.name, c.owner
		ORDER BY c.name`
	rows, err := db.DB.Query(q, "%"+search+"%")
	if err != nil { return nil }
	defer rows.Close()
	out := []struct{id int64; name, owner string; open, overdue int}{}
	for rows.Next(){
		var r struct{id int64; name, owner string; open, overdue int}
		rows.Scan(&r.id,&r.name,&r.owner,&r.open,&r.overdue)
		out = append(out, r)
	}
	return out
}

func queryReport(name string) ([][]string, []string) {
	switch name {
	case "Tareas por estado":
		rows, _ := db.DB.Query("SELECT status, COUNT(*) FROM tasks GROUP BY status")
		return rowsToStrings(rows, []string{"Estado","Cantidad"})
	case "Vencidas por responsable":
		rows, _ := db.DB.Query("SELECT assignee, COUNT(*) FROM tasks WHERE status!='Hecho' AND due_date IS NOT NULL AND date(due_date) < date('now') GROUP BY assignee")
		return rowsToStrings(rows, []string{"Responsable","Vencidas"})
	case "Tareas por cliente":
		rows, _ := db.DB.Query("SELECT c.name, COUNT(*) FROM tasks t JOIN clients c ON t.client_id=c.id GROUP BY c.name")
		return rowsToStrings(rows, []string{"Cliente","Cantidad"})
	case "Productividad semanal":
		rows, _ := db.DB.Query("SELECT strftime('%Y-W%W', created_at), COUNT(*) FROM tasks WHERE status='Hecho' GROUP BY strftime('%Y-W%W', created_at)")
		return rowsToStrings(rows, []string{"Semana","Completadas"})
	}
	return [][]string{}, []string{"Col1","Col2"}
}

func rowsToStrings(rows *sql.Rows, headers []string) ([][]string, []string) {
	if rows==nil { return [][]string{}, headers }
	defer rows.Close()
	out := [][]string{}
	for rows.Next(){
		var a, b sql.NullString
		rows.Scan(&a, &b)
		out = append(out, []string{a.String, b.String})
	}
	return out, headers
}
