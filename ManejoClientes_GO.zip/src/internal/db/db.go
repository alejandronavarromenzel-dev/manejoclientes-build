
package db

import (
	"database/sql"
	"fmt"
	"os"
	"path/filepath"
	"time"

	_ "github.com/ncruces/go-sqlite3"
)

var DB *sql.DB

func dataDir() string {
	base, _ := os.Executable()
	root := filepath.Dir(base)
	return filepath.Join(root, "data")
}

func backupsDir() string {
	base, _ := os.Executable()
	root := filepath.Dir(base)
	return filepath.Join(root, "backups")
}

func dbPath() string { return filepath.Join(dataDir(), "crm.db") }

func Init() error {
	os.MkdirAll(dataDir(), 0755)
	os.MkdirAll(backupsDir(), 0755)

	dsn := dbPath()
	d, err := sql.Open("sqlite", dsn)
	if err != nil { return err }
	if err = d.Ping(); err != nil { return err }
	DB = d
	if err := migrate(); err != nil { return err }
	if err := seed(); err != nil { return err }
	return nil
}

func migrate() error {
	sqlSchema := `
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS clients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  owner TEXT,
  email TEXT,
  phone TEXT,
  status TEXT,
  tags TEXT,
  industry TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  notes TEXT
);

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  priority TEXT,
  status TEXT,
  due_date TEXT,
  start_date TEXT,
  progress INTEGER DEFAULT 0,
  assignee TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(client_id) REFERENCES clients(id)
);
`
	_, err := DB.Exec(sqlSchema)
	return err
}

func seed() error {
	var n int
	_ = DB.QueryRow("SELECT COUNT(*) FROM clients").Scan(&n)
	if n > 0 { return nil }

	tx, err := DB.Begin()
	if err != nil { return err }
	defer tx.Rollback()
	// Clients
	clients := [][]any{
		{"ACME Ltda.", "Ana", "contacto@acme.com", "+56 2 12345678", "Activo", "VIP", "Retail", "Cliente clave"},
		{"Fenix S.A.", "Luis", "ventas@fenix.com", "+56 2 99999999", "Activo", "", "Tecnología", ""},
		{"Innotech", "Sofía", "info@innotech.cl", "+56 2 55555555", "Prospecto", "Nuevo", "Servicios", ""},
	}
	for _, c := range clients {
		if _, err := tx.Exec(`INSERT INTO clients(name, owner, email, phone, status, tags, industry, notes) VALUES(?,?,?,?,?,?,?,?)`, c...); err != nil { return err }
	}
	// Map client IDs
	type pair struct{ id int64; name string }
	rows, _ := tx.Query("SELECT id, name FROM clients")
	m := map[string]int64{}
	for rows.Next() {
		var p pair
		rows.Scan(&p.id, &p.name)
		m[p.name] = p.id
	}
	rows.Close()

	now := time.Now()
	tasks := []struct{ client string; title, desc, prio, status, due, start, assignee string; prog int }{
		{"ACME Ltda.", "Instalar demo", "Instalación inicial", "Alta", "En curso", now.AddDate(0,0,5).Format("2006-01-02"), now.AddDate(0,0,-2).Format("2006-01-02"), "Ana", 40},
		{"	ACME Ltda.", "Reunión de seguimiento", "Coordinar agenda", "Media", "Por hacer", now.AddDate(0,0,7).Format("2006-01-02"), "", "Luis", 0},
		{"Fenix S.A.", "Enviar propuesta", "Versión 1.0", "Alta", "Por hacer", now.AddDate(0,0,6).Format("2006-01-02"), "", "Luis", 0},
		{"Innotech", "Llamada de descubrimiento", "Revisar necesidades", "Baja", "Hecho", now.AddDate(0,0,-6).Format("2006-01-02"), now.AddDate(0,0,-8).Format("2006-01-02"), "Sofía", 100},
	}
	for _, t := range tasks {
		cid := m[t.client]
		if _, err := tx.Exec(`INSERT INTO tasks(client_id, title, description, priority, status, due_date, start_date, progress, assignee) VALUES(?,?,?,?,?,?,?,?,?)`,
			cid, t.title, t.desc, t.prio, t.status, t.due, t.start, t.prog, t.assignee); err != nil { return err }
	}
	return tx.Commit()
}

func BackupNow() (string, error) {
	src := dbPath()
	dst := filepath.Join(backupsDir(), time.Now().Format("20060102_150405")+"_crm.db")
	in, err := os.ReadFile(src)
	if err != nil { return "", err }
	if err := os.WriteFile(dst, in, 0644); err != nil { return "", err }
	return dst, nil
}
