
Write-Host "Preparando entorno Go..." -ForegroundColor Cyan
$ErrorActionPreference = 'Stop'

# Ir al directorio src para el build
Push-Location "$PSScriptRoot\src"

# Descarga dependencias
go mod download

Write-Host "Compilando EXE (Windows GUI)..." -ForegroundColor Cyan
# -H=windowsgui oculta la consola; -s -w reduce tamaño
$env:CGO_ENABLED = "0"
go build -ldflags "-H=windowsgui -s -w" -o "$PSScriptRoot\ManejoClientes.exe" ./cmd/manejoclientes

Pop-Location

if (Test-Path "$PSScriptRoot\ManejoClientes.exe") {
  Write-Host "Listo: $PSScriptRoot\ManejoClientes.exe" -ForegroundColor Green
} else {
  Write-Host "No se generó el EXE. Revisa mensajes anteriores." -ForegroundColor Red
  exit 1
}
