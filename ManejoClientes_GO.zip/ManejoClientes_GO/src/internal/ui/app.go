package ui

import (
	"database/sql"
	"fmt"
	"strconv"
	"strings"

	fyne "fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"

	"manejoclientes/internal/db"
	"manejoclientes/internal/models"
)

var (
	w fyne.Window
)

func RunApp() {
	a := app.NewWithID("manejoclientes")
	a.Settings().SetTheme(theme.LightTheme())
	w = a.NewWindow("Manejo Clientes")
	w.Resize(fyne.NewSize(1366, 768))

	if err := db.Init(); err != nil {
		dialog.ShowError(err, w)
		return
	}

	nb := container.NewAppTabs()
	nb.Append(container.NewTabItem("Kanban", buildKanban()))
	nb.Append(container.NewTabItem("Clientes", buildClientes()))
	nb.Append(container.NewTabItem("Tareas", buildTareas()))
	nb.Append(container.NewTabItem("Reportes", buildReportes()))
	nb.Append(container.NewTabItem("Importar/Exportar", buildImportExport()))
	nb.Append(container.NewTabItem("Ajustes", buildAjustes()))
	nb.SetTabLocation(container.TabLocationTop)

	w.SetContent(nb)

	w.SetCloseIntercept(func() {
		if _, err := db.BackupNow(); err != nil {
			// no bloquear cierre por error de backup
		}
		w.Close()
	})

	w.ShowAndRun()
}

// ---------- Kanban ----------
func buildKanban() fyne.CanvasObject {
	col := func(title string, list *widget.List) fyne.CanvasObject {
		lbl := widget.NewLabelWithStyle(title, fyne.TextAlignCenter, fyne.TextStyle{Bold: true})
		return container.NewBorder(lbl, nil, nil, nil, list)
	}

	var tasks []models.Task
	reload := func() { tasks = queryTasks("", "", "") }
	reload()

	filter := func(status string) []models.Task {
		arr := []models.Task{}
		for _, t := range tasks {
			if t.Status == status {
				arr = append(arr, t)
			}
		}
		return arr
	}

	makeList := func(getter func() []models.Task) *widget.List {
		items := getter()
		l := widget.NewList(
			func() int { return len(items) },
			func() fyne.CanvasObject { return widget.NewLabel("item") },
			func(i widget.ListItemID, o fyne.CanvasObject) {
				if i < 0 || i >= len(items) {
					return
				}
				o.(*widget.Label).SetText(
					fmt.Sprintf("#%d %s — %s — %s",
						items[i].ID,
						items[i].Title,
						items[i].ClientName,
						items[i].Assignee,
					),
				)
			},
		)
		l.OnSelected = func(id widget.ListItemID) {
			if id < 0 || id >= len(items) {
				return
			}
			showTaskEdit(items[id].ID, func() {
				reload()
				porHacer.Refresh()
				enCurso.Refresh()
				hecho.Refresh()
			})
		}
		return l
	}

	porHacer := makeList(func() []models.Task { return filter("Por hacer") })
	enCurso := makeList(func() []models.Task { return filter("En curso") })
	hecho := makeList(func() []models.Task { return filter("Hecho") })

	btnAdd := widget.NewButton("Agregar tarea", func() {
		showTaskEdit(0, func() {
			reload()
			porHacer.Refresh()
			enCurso.Refresh()
			hecho.Refresh()
		})
	})

	grid := container.NewGridWithColumns(3,
		col("Por hacer", porHacer),
		col("En curso", enCurso),
		col("Hecho", hecho),
	)

	return container.NewBorder(container.NewHBox(btnAdd), nil, nil, nil, grid)
}

// ---------- Clientes ----------
func buildClientes() fyne.CanvasObject {
	search := widget.NewEntry()
	search.SetPlaceHolder("Buscar cliente...")

	btn := widget.NewButton("Filtrar", nil)
	add := widget.NewButton("Agregar cliente", nil)

	table := widget.NewTable(
		func() (int, int) { return 0, 5 },
		func() fyne.CanvasObject { return widget.NewLabel("") },
		func(id widget.TableCellID, o fyne.CanvasObject) {},
	)

	refresh := func() {
		rows := queryClientsWithStats(strings.TrimSpace(search.Text))
		table.Length = func() (int, int) { return len(rows) + 1, 5 }
		table.UpdateCell = func(id widget.TableCellID, o fyne.CanvasObject) {
			lbl := o.(*widget.Label)
			if id.Row == 0 {
				headers := []string{"ID", "Cliente", "Responsable", "Abiertas", "Vencidas"}
				lbl.SetText(headers[id.Col])
				return
			}
			r := rows[id.Row-1]
			switch id.Col {
			case 0:
				lbl.SetText(fmt.Sprintf("%d", r.id))
			case 1:
				lbl.SetText(r.name)
			case 2:
				lbl.SetText(r.owner)
			case 3:
				lbl.SetText(fmt.Sprintf("%d", r.open))
			case 4:
				lbl.SetText(fmt.Sprintf("%d", r.overdue))
			}
		}
		table.Refresh()
	}

	btn.OnTapped = refresh
	add.OnTapped = func() { showClientEdit(0, refresh) }
	refresh()

	return container.NewBorder(
		container.NewHBox(add, widget.NewLabel("  "), search, btn),
		nil, nil, nil, table,
	)
}

// ---------- Import/Export ----------
func buildImportExport() fyne.CanvasObject {
	info := widget.NewRichTextFromMarkdown(`**Importar/Exportar**
- Clientes (XLSX)
- Tareas (XLSX)`)

	impC := widget.NewButton("Importar clientes (XLSX)", func() { doImportClientsXLSX() })
	expC := widget.NewButton("Exportar clientes (XLSX)", func() { doExportClientsXLSX() })
	impT := widget.NewButton("Importar tareas (XLSX)", func() { doImportTasksXLSX() })
	expT := widget.NewButton("Exportar tareas (XLSX)", func() { doExportTasksXLSX() })

	return container.NewVBox(info, impC, expC, impT, expT)
}

// ---------- Ajustes ----------
func buildAjustes() fyne.CanvasObject {
	lbl := widget.NewLabel("Backups automáticos al cerrar: ACTIVOS\nCarpeta: backups")
	lbl.TextStyle = fyne.TextStyle{Monospace: true}
	return container.NewVBox(
		widget.NewLabelWithStyle("Ajustes", fyne.TextAlignLeading, fyne.TextStyle{Bold: true}),
		lbl,
	)
}

// ---------- Utilidades ----------
func valueOr(s *string, def string) string {
	if s == nil {
		return def
	}
	return *s
}

func exec(sql string, args ...any) error {
	_, err := db.DB.Exec(sql, args...)
	return err
}
