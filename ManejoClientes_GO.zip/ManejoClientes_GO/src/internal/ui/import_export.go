
package ui

import (
	"database/sql"
	"fmt"
	"strings"

	"github.com/xuri/excelize/v2"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/storage"

	"manejoclientes/internal/db"
)

func doExportClientsXLSX() {
	f := excelize.NewFile()
	sh := "clients"
	f.NewSheet(sh)
	f.SetSheetRow(sh, "A1", &[]any{"id","name","owner","email","phone","status","tags","industry","created_at","notes"})
	rows, err := db.DB.Query("SELECT id,name,owner,email,phone,status,tags,industry,created_at,notes FROM clients ORDER BY name")
	if err!=nil { dialog.ShowError(err, w); return }
	defer rows.Close()
	i := 2
	for rows.Next(){
		var r [10]sql.NullString
		real := make([]any, 10)
		rows.Scan(&r[0],&r[1],&r[2],&r[3],&r[4],&r[5],&r[6],&r[7],&r[8],&r[9])
		for j:=0;j<10;j++{ real[j] = r[j].String }
		addr := fmt.Sprintf("A%d", i)
		f.SetSheetRow(sh, addr, &real)
		i++
	}
	saveExcel(f, "clientes.xlsx")
}

func doExportTasksXLSX() {
	f := excelize.NewFile()
	sh := "tasks"
	f.NewSheet(sh)
	f.SetSheetRow(sh, "A1", &[]any{"id","client_name","title","description","priority","status","due_date","start_date","progress","assignee"})
	rows, err := db.DB.Query(`SELECT t.id, c.name, t.title, t.description, t.priority, t.status, t.due_date, t.start_date, t.progress, t.assignee
		FROM tasks t JOIN clients c ON t.client_id=c.id ORDER BY t.id`)
	if err!=nil { dialog.ShowError(err, w); return }
	defer rows.Close()
	i := 2
	for rows.Next(){
		var a [10]sql.NullString
		real := make([]any, 10)
		rows.Scan(&a[0],&a[1],&a[2],&a[3],&a[4],&a[5],&a[6],&a[7],&a[8],&a[9])
		for j:=0;j<10;j++{ real[j] = a[j].String }
		addr := fmt.Sprintf("A%d", i)
		f.SetSheetRow(sh, addr, &real)
		i++
	}
	saveExcel(f, "tareas.xlsx")
}

func saveExcel(f *excelize.File, defaultName string){
	u := storage.NewFileURI(defaultName)
	d := dialog.NewFileSave(func(rc fyne.URIWriteCloser, err error){
		if err!=nil || rc==nil { return }
		defer rc.Close()
		if err := f.Write(rc); err!=nil { dialog.ShowError(err, w) } else { dialog.ShowInformation("Exportar", "Excel exportado", w) }
	}, w)
	d.SetFileName(defaultName)
	d.Show()
}

func doImportClientsXLSX(){
	d := dialog.NewFileOpen(func(rc fyne.URIReadCloser, err error){
		if err!=nil || rc==nil { return }
		defer rc.Close()
		f, err := excelize.OpenReader(rc)
		if err!=nil { dialog.ShowError(err, w); return }
		rows, err := f.GetRows("clients")
		if err!=nil { dialog.ShowError(err, w); return }
		for i, r := range rows {
			if i==0 { continue }
			vals := make([]any, 8)
			for j:=0;j<8 && j<len(r); j++ { vals[j] = strings.TrimSpace(r[j]) }
			_, err := db.DB.Exec(`INSERT INTO clients(name, owner, email, phone, status, tags, industry, notes) VALUES(?,?,?,?,?,?,?,?)`, vals...)
			if err!=nil { dialog.ShowError(err, w); return }
		}
		dialog.ShowInformation("Importar", "Clientes importados", w)
	}, w)
	d.Show()
}

func doImportTasksXLSX(){
	d := dialog.NewFileOpen(func(rc fyne.URIReadCloser, err error){
		if err!=nil || rc==nil { return }
		defer rc.Close()
		f, err := excelize.OpenReader(rc)
		if err!=nil { dialog.ShowError(err, w); return }
		rows, err := f.GetRows("tasks")
		if err!=nil { dialog.ShowError(err, w); return }
		// build client map
		m := map[string]int64{}
		cr, _ := db.DB.Query("SELECT id,name FROM clients")
		for cr.Next(){ var id int64; var name string; cr.Scan(&id,&name); m[name]=id }
		cr.Close()

		for i, r := range rows {
			if i==0 { continue }
			// client_name, title, description, priority, status, due_date, start_date, progress, assignee
			clientName := strings.TrimSpace(getCell(r,1))
			if clientName=="" { continue }
			cid, ok := m[clientName]
			if !ok { res, _ := db.DB.Exec("INSERT INTO clients(name) VALUES(?)", clientName); id, _ := res.LastInsertId(); cid = id; m[clientName]=cid }
			title := strings.TrimSpace(getCell(r,2)); if title=="" { continue }
			desc := strings.TrimSpace(getCell(r,3))
			prio := strings.TrimSpace(getCell(r,4))
			status := strings.TrimSpace(getCell(r,5)); if status!="Por hacer" && status!="En curso" && status!="Hecho" { status = "Por hacer" }
			due := strings.TrimSpace(getCell(r,6))
			start := strings.TrimSpace(getCell(r,7))
			prog := strings.TrimSpace(getCell(r,8)); if prog=="" { prog = "0" }
			ass := strings.TrimSpace(getCell(r,9))
			_, err := db.DB.Exec(`INSERT INTO tasks(client_id, title, description, priority, status, due_date, start_date, progress, assignee) VALUES(?,?,?,?,?,?,?,?,?)`,
				cid, title, desc, prio, status, nilIfEmpty(due), nilIfEmpty(start), prog, ass)
			if err!=nil { dialog.ShowError(err, w); return }
		}
		dialog.ShowInformation("Importar", "Tareas importadas", w)
	}, w)
	d.Show()
}

func getCell(r []string, idx int) string { if idx<0 || idx>=len(r){return ""}; return r[idx] }
func nilIfEmpty(s string) any { if strings.TrimSpace(s)=="" { return nil }; return s }
