
package main

import (
	"manejoclientes/internal/ui"
)

func main() {
	ui.RunApp()
}
