
# ManejoClientes (Go + Fyne) — Offline, EXE único

**Qué incluye**
- Kanban (Por hacer / En curso / Hecho) — *doble clic para mover estado*.
- Clientes y Tareas (CRUD básico).
- Reportes (estado, vencidas por responsable, por cliente, productividad semanal).
- Importar/Exportar **Excel (.xlsx)** con **excelize**.
- **SQLite** embebido (driver pure-Go `github.com/ncruces/go-sqlite3` — sin CGO, sin GCC).
- **Backups automáticos** al cerrar (carpeta `backups` junto al EXE).
- Idioma: **100% español**. Resolución objetivo: **1366x768**.

## Requisitos para generar el EXE
- Windows 10/11 con **Go 1.22+** instalado: https://go.dev/dl/
- PowerShell.

## Generar el EXE (un solo paso)
1. Abre PowerShell en esta carpeta.
2. Ejecuta:
   ```powershell
   ./build_windows.ps1
   ```
3. Se crea `ManejoClientes.exe` en esta misma carpeta.
4. Doble clic para abrir la app.

> Si SmartScreen bloquea el EXE: Propiedades → **Desbloquear** → Aceptar.

## Importar desde Excel
Plantillas esperadas:
- **Clientes**: columnas `name, owner, email, phone, status, tags, industry, notes`
- **Tareas**: columnas `client_name, title, description, priority, status, due_date(YYYY-MM-DD), start_date(YYYY-MM-DD), progress(0-100), assignee`

Si `client_name` no existe, se crea el cliente automáticamente.

## Notas
- Drag & drop completo en Kanban está **planificado**; en este MVP se usa **doble clic** para mover estado (rápido y confiable en Fyne), y botones.
- La base `data/crm.db` se crea/actualiza en el primer arranque.

